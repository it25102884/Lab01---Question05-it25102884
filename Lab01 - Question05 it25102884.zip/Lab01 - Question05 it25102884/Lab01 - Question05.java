class Lab01 - Question05 
{
    // Implement three methods [cite: 41, 42, 43]
    public int add(int a, int b) { return a + b; }
    public int multiply(int a, int b) { return a * b; }
    public int square(int x) { return x * x; }
}

public class Main 
{
    public static void main(String[] args) 
	{
        Calculator calc = new Calculator();

        // 1. (3*4 + 5*7)^2 [cite: 45]
        int term1 = calc.multiply(3, 4);
        int term2 = calc.multiply(5, 7);
        int result1 = calc.square(calc.add(term1, term2));
        System.out.println("Expression 1: " + result1);

        // 2. (4+7)^2 + (8+3)^2 [cite: 46]
        int result2 = calc.add(calc.square(calc.add(4, 7)), calc.square(calc.add(8, 3)));
        System.out.println("Expression 2: " + result2);
    }
}